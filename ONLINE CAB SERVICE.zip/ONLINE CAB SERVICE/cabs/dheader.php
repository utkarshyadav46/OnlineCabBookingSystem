<html>
<body>
<div data-role="header">
	<h1>WELCOME<?php echo " $driver_check"; echo "$driver_id"?> (DRIVER PORTAL ACCOUNT)</h1>
	<div data-role="navbar">
		<ul>
		    <li><a href="#homePage">GEOLOCATION</a></li>
			<li><a href="#mapPage">POSITION ON MAP</a></li>
			<li><a href="#passenger">SEE PASSENGER</a></li>
			<li><a href="#account">ACCOUNT</a></li>
			<li><button onclick="myFunction()">LOGOUT</button></li>
			
			
		</ul>
	</div><!-- /navbar -->
</div><!-- /header -->
</body>
</html>
