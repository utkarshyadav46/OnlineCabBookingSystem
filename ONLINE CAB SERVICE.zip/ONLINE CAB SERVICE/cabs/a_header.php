<html>
<body>
<div data-role="header">
	<h1>WELCOME (ADMIN PORTAL ACCOUNT)</h1>
	<div data-role="navbar">
		<ul>
		    <li><a href="#homePage">SEE USERS</a></li>
		    <li><a href="#passenger">SEE RECORD</a></li>
			<li><a href="#drivers">SEE DRIVERS</a></li>
			
		</ul>
	</div><!-- /navbar -->
</div><!-- /header -->
</body>
</html>
