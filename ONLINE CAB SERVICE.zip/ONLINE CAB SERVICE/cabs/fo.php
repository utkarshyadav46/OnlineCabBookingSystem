<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";
$email=$_POST['email'];
$conn = mysqli_connect($servername, $username, $password, $dbname);
if(isset($_POST['send']))
{
	$fp=rand(100000,999999);
	
	$sql="update logintable set Forgot_password='$fp' where email='$email'";
	mysqli_query($conn,$sql);
	echo "<a href=mailto:".$email."?subject=This%20is%20the%20subject&cc=2016kucp1024@iiitkota.ac.in&body=your%20otp%20is%20".$fp."><button>SEND OTP</button></a>";
 }
?>
<form action="pass.php" method="post">
<input type="text" placeholder="ENTER THE OTP THAT IS ENT TO YOU " name="otp"   required/>
<input type ="submit" name="show" value="SHOW PASSWORD" />
</form>
