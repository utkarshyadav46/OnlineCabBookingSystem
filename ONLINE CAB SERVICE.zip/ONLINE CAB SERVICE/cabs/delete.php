<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";
$use=$_SESSION['tno'];
$driver_id = $_SESSION['login_id'];
$conn = mysqli_connect($servername, $username, $password, $dbname);
if ($conn->connect_error) 
{
     die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['cancel']))
{
$update1="DELETE from travel_history where Status='pending' and Driver_id=$driver_id && Travel_no='$use' ";
if(mysqli_query($conn,$update1))
{

} else {
    echo "ERROR: Could not able to execute $update2. " . mysqli_error($uodate1);
}
header("location:driver_session.php");  
}
else if(isset($_POST['confirm']))
{
	echo "ayush";
$update2="update travel_history set Status='running' where Status='pending' and Driver_id=$driver_id";
$update3="update drivers set Available='NO' where  id=$driver_id and Available='YES'";
if(mysqli_query($conn,$update3))
{
echo"hellsdsds";
} 
else {
    echo "ERROR: Could not able to execute $update2. " . mysqli_error($update3);
}
if(mysqli_query($conn,$update2)){
	 $sql3="SELECT * from travel_history where Driver_id=$driver_id && Status='running'";
$result = $conn->query($sql3);
if ($result->num_rows > 0) 
{
	echo "<h1>YOU HAVE TO TAKE.... </h1>";
	echo "<table><tr><th>ID </th><th> CUSTOMER_NAME</th><th>FROM</th><th> TO</th><th>  FARE </th><th>EARNING</th><th>STATUS</th></tr>";
while($row = $result->fetch_assoc()) 
	{
	echo "<h1>".$row["Tourist_name"]."<h1>";
     echo "<tr><td>    &nbsp".$row["Travel_no"]." </td><td>  &nbsp    ".$row["Tourist_name"]." </td><td>   ".$row["Starting_point"]." </td> <td>   ".$row["Destination"]." </td><td>      ".$row["Fare"]."</td><td>          ".$row["Dsalary"]."</td><td><h3>CATCH THE TOURIST</h3></td></tr>";
	}
	echo "</table>";
}
} else {
    echo "ERROR: Could not able to execute $update2. " . mysqli_error($sql3);
}
header("location:driver_session.php");
}
  

 

$conn->close();
?>
