<html>
<body>
<form  action="fo.php" method="post" >
ENTER EMAIL
<br><input type="email" placeholder="enter your email" name="email" required/>
<input type="submit" value="CONFIRM"  name="send">
</form>
<br><br>
</body>
</html>

 

