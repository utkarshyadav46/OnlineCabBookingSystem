
<form action=" a1.php" method="post">
<center><h1><b><i><u>FEEDBACK FORM</u></i></b></h1><br><br></font>
<font size="50px"></font>
<h3><b>NAME:</b><input type="text" name="name" placeholder="Enter Your Name"><br><br>
<b>E-MAIL ID:</b><input type="text" name="mail_id" placeholder="Enter E-mail Id"><br><br>
<b>CONTACT NO:</b><input type="text" name="contactno" placeholder="Enter Mobile No."><br><br>
<b>RATE US:</b><input type="radio" name="rate" value="1"> 1     
<input type="radio" name="rate" value="2">2      <input type="radio" name="rate" value="3">3      <input type="radio" name="rate" value="4">4      <input type="radio" name="rate" value="5">5      <br><br>
<b>SUGGESTIONS</b><textarea rows="6" columns="40" name="suggestion" placeholder="ENTER YOUR SUGGESTIONS TO IMPROVE OUR SERVICES:-" > </textarea><br><br>
<button type="submit"  value="Submit">submit</button></h3></form></center>
