<html>
<body>
<div data-role="header">
	<h1>WELCOME<?php echo " $user_check"; ?>(CUSTOMER PORTAL)</h1>
	<div data-role="navbar">
		<ul>
		    <li><a href="#homePage">GEOLOCATION</a></li>
			<li><a href="#mapPage">POSITION ON MAP</a></li>
			<li><a href="#directionsPage">BOOKING</a></li>
			<li><a href="#history">ACCOUNT</a></li>
			<li><button onclick="myFunction()">LOGOUT</button></li>
			
			
		</ul>
	</div><!-- /navbar -->
</div><!-- /header -->
</body>
</html>
